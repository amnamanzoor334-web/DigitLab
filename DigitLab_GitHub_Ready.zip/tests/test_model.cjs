const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const root=path.resolve(__dirname,'..'),sandbox={window:{}};vm.runInNewContext(fs.readFileSync(path.join(root,'model.js'),'utf8'),sandbox);
const m=JSON.parse(JSON.stringify(sandbox.window.DIGIT_MODEL)),{predict}=require('../inference.js');
for(const s of m.samples){const r=predict(s.pixels,m);assert.equal(r.ranks.length,10);assert.ok(Math.abs(r.ranks.reduce((n,x)=>n+x.score,0)-1)<1e-12);assert.equal(r.digit,r.ranks[0].digit);}
for(const bad of [[],Array(64).fill(0),Array(64).fill(NaN),Array(64).fill(17),Array(64).fill(-1)])assert.throws(()=>predict(bad,m));
assert.equal(m.metrics.matrix.flat().reduce((a,b)=>a+b,0),360);assert.equal(m.metrics.matrix.reduce((s,row,i)=>s+row[i],0),350);
console.log('Input validation, probability normalization and evaluation consistency passed.');
