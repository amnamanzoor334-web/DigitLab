from pathlib import Path
import json,subprocess,numpy as np
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
D=load_digits();train,test=train_test_split(np.arange(len(D.target)),test_size=.2,random_state=42,stratify=D.target)
s=StandardScaler().fit(D.data[train]);clf=LogisticRegression(C=1,max_iter=2000,random_state=42).fit(s.transform(D.data[train]),D.target[train]);expected=clf.predict_proba(s.transform(D.data[test]))
r=subprocess.run(['node',str(Path(__file__).with_name('predict_batch.cjs'))],input=json.dumps(D.data[test].tolist()),text=True,capture_output=True,check=True);got=json.loads(r.stdout)
for i,g in enumerate(got):
    assert g['digit']==int(clf.classes_[expected[i].argmax()])
    p={x['digit']:x['score'] for x in g['ranks']}
    assert np.allclose([p[int(c)] for c in clf.classes_],expected[i],atol=1e-10,rtol=1e-10)
print('All 360 held-out predictions and probabilities match Python.')
