from pathlib import Path
import json
import numpy as np
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score,classification_report,confusion_matrix
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'dist' if (ROOT/'dist').is_dir() else ROOT
D=load_digits();indices=np.arange(len(D.target));train,test=train_test_split(indices,test_size=.2,random_state=42,stratify=D.target)
s=StandardScaler().fit(D.data[train]);clf=LogisticRegression(C=1,max_iter=2000,random_state=42).fit(s.transform(D.data[train]),D.target[train]);pred=clf.predict(s.transform(D.data[test]));coef=clf.coef_/s.scale_;intercept=clf.intercept_-coef@s.mean_
samples=[{'id':int(i),'label':int(D.target[i]),'pixels':D.data[i].tolist()} for digit in range(10) for i in [next(j for j in test if D.target[j]==digit)]]
metrics={'accuracy':float(accuracy_score(D.target[test],pred)),'correct':int((pred==D.target[test]).sum()),'test_count':len(test),'train_count':len(train),'total':len(indices),'seed':42,'matrix':confusion_matrix(D.target[test],pred).tolist(),'report':classification_report(D.target[test],pred,output_dict=True),'method':'StandardScaler and logistic regression','split':'Stratified random split, 80 percent training and 20 percent testing; random_state 42'}
model={'coef':coef.tolist(),'intercept':intercept.tolist(),'classes':clf.classes_.tolist(),'metrics':metrics,'samples':samples}
(OUT/'model.js').write_text('window.DIGIT_MODEL='+json.dumps(model,separators=(',',':'))+';')
(ROOT/'evaluation.json').write_text(json.dumps(metrics,indent=2))
print(json.dumps({'accuracy':metrics['accuracy'],'correct':metrics['correct'],'test_count':metrics['test_count'],'train_count':metrics['train_count']}))
